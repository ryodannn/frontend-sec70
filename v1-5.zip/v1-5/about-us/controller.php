<?php
# NOTA: Algunas partes del codigo fueron extraidas del ejemplo de la clase

class ControladorSobreNosotros {
    private $sobre_nosotros;

    public function __construct() {
        $this->sobre_nosotros = [];
    }

    public function obtenerSobreNosotros() {
        $connection = new Connection();
        $sql = "SELECT * FROM sobre_nosotros;";
        $rs = mysqli_query($connection->obtenerConexion(), $sql);
        if ($rs) {
            while ($sobre_nos = mysqli_fetch_assoc($rs)) {
                $this->sobre_nosotros[] = $sobre_nos;
            }
            mysqli_free_result($rs);
        }
        $connection->closeConnection();
        return $this->sobre_nosotros;
    }
}