<?php
# NOTA: Algunas partes del codigo fueron extraidas del ejemplo de la clase
global $_parametros, $_version, $_endpoint, $_metodo, $_header, $_token_get;
include_once '../version1.php';

if ($_version == 'v1') {
    if($_endpoint == 'about-us') {
        switch ($_metodo) {
            case 'GET':
            if ($_header == $_token_get) {
                include_once '../conexion.php';
                include_once 'controller.php';
                $controlador = new ControladorSobreNosotros();
                $sobreNosotros = $controlador->obtenerSobreNosotros();

                foreach ($sobreNosotros as $sobreNos) {
                    $r['id'] = $sobreNos['id'];
                    $titulo['esp'] = $sobreNos['titulo_esp'];
                    $contenido['esp'] = $sobreNos['contenido_esp'];
                    $r['titulo'] = $titulo;
                    $r['contenido'] = $contenido;
                    $sobre[] = $r;
                }

                $result['mision'] = $sobre[0];
                $result['vision'] = $sobre[1];
                http_response_code(200);
                echo json_encode(['data' => $result]);
            } else {
                http_response_code(401);
                echo json_encode(['error' => 'No tiene autorizacion']);
            }
                break;
            default:
                http_response_code(405);
                echo json_encode(['error' => 'Metodo no permitido']);
                break;
        }
    }
}