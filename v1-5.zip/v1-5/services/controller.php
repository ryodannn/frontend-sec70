<?php
# NOTA: Algunas partes del codigo fueron extraidas del ejemplo de la clase

class ControladorServicios {
    private $servicios;

    public function __construct() {
        $this->servicios = [];
    }

    public function obtenerServicios() {
        $connection = new Connection();
        $sql = "SELECT * FROM servicios;";
        $rs = mysqli_query($connection->obtenerConexion(), $sql);
        if ($rs) {
            while ($servicio = mysqli_fetch_assoc($rs)) {
                $this->servicios[] = $servicio; // Filtrar solo activos
            }
            mysqli_free_result($rs);
        }
        $connection->closeConnection();
        return $this->servicios;
    }
}