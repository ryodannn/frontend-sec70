<?php
# NOTA: Algunas partes del codigo fueron extraidas del ejemplo de la clase
global $_parametros, $_version, $_endpoint, $_metodo, $_header, $_token_get;
include_once '../version1.php';

if ($_version == 'v1') {
    if($_endpoint == 'services') {
        switch ($_metodo) {
            case 'GET':
            if ($_header == $_token_get) {
                include_once '../conexion.php';
                include_once 'controller.php';
                $controlador = new ControladorServicios();

                $resultado = [];
                $services = $controlador->obtenerServicios();
                foreach ($services as $service) {
                    $r['id'] = $service['id'];

                    $titulo['esp'] = $service['titulo_esp'];
                    $texto['esp'] = $service['texto_esp'];

                    $r['titulo'] = $titulo;
                    $r['texto'] = $texto;

                    $resultado[] = $r;
                }
                http_response_code(200);
                echo json_encode(['data' => $resultado]);
            } else {
                http_response_code(401);
                echo json_encode(['error' => 'No tiene autorizacion']);
            }
                break;
            default:
                http_response_code(405);
                echo json_encode(['error' => 'Metodo no permitido']);
                break;
        }
    }
}