<?php
# NOTA: Algunas partes del codigo fueron extraidas del ejemplo de la clase

$_esquema = $_SERVER['REQUEST_SCHEME'];
$_ubicacion = $_SERVER['HTTP_HOST'];
$_metodo = $_SERVER['REQUEST_METHOD'];
$_path = $_SERVER['REQUEST_URI'];

$_partes = explode('/', $_path);
$_version = $_ubicacion == 'localhost' ? $_partes[1] : null;
$_endpoint = $_ubicacion == 'localhost' ? $_partes[2] : null;

header("Access-Control-Allow-Origin: *");
header("Access-Control-ALlow-Methods: GET, POST, PUT, PATH, DELETE");
header("Content-Type: application/json; charset=UTF-8");

//Authorization Bearer
$_header = isset(getallheaders()['Authorization']) ? getallheaders()['Authorization'] : null;

//Tokens
$_token_get = 'Bearer get';
$_token_post = 'Bearer post';
$_token_put = 'Bearer put';
$_token_patch = 'Bearer patch';
$_token_delete = 'Bearer delete';