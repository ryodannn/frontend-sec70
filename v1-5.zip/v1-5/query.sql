# NOTA: Algunas partes del codigo fueron extraidas del ejemplo de la clase

# CLEAR / LIMPIAR
DROP TABLE servicios;
DROP TABLE sobre_nosotros;

DROP DATABASE trabajo_ciisa;
DROP USER IF EXISTS 'trabajo_ciisa'@'localhost';

# CREATE NECESARY / CREAR COSAS NECESARIAS
CREATE DATABASE trabajo_ciisa;
CREATE USER 'trabajo_ciisa'@'localhost' IDENTIFIED BY 'l4cl4v3-c11s4';
GRANT ALL PRIVILEGES ON trabajo_ciisa.* TO 'trabajo_ciisa'@'localhost';
FLUSH PRIVILEGES;

# USE PROJECT DATABASE / USAR BASE DE DATOS DEL PROYECTO
USE trabajo_ciisa;

CREATE TABLE servicios (
    id  INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    titulo_esp VARCHAR(255),
    texto_esp TEXT,
    activo BOOLEAN DEFAULT true
);

CREATE TABLE sobre_nosotros (
    id  INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    titulo_esp VARCHAR(255),
    contenido_esp TEXT
);

-- INSERTAR DATOS servicios
INSERT INTO servicios (titulo_esp, texto_esp) VALUES ('Consultoría digital', 'Identificamos las fallas y conectamos los puntos entre tu negocio y tu estrategia digital. Nuestro equipo experto cuenta con años de experiencia en la definición de estrategias y hojas de ruta en función de tus objetivos específicos.');
INSERT INTO servicios (titulo_esp, texto_esp) VALUES ('Soluciones multiexperiencia', 'Deleitamos a las personas usuarias con experiencias interconectadas a través de aplicaciones web, móviles, interfaces conversacionales, digital twin, IoT y AR. Su arquitectura puede adaptarse y evolucionar para adaptarse a los cambios de tu organización.');
INSERT INTO servicios (titulo_esp, texto_esp) VALUES ('Evolución de ecosistemas', 'Ayudamos a las empresas a evolucionar y ejecutar sus aplicaciones de forma eficiente, desplegando equipos especializados en la modernización y el mantenimiento de ecosistemas técnicos. Creando soluciones robustas en tecnologías de vanguardia.');
INSERT INTO servicios (titulo_esp, texto_esp) VALUES ('Soluciones Low-Code', 'Traemos el poder de las soluciones low-code y no-code para ayudar a nuestros clientes a acelerar su salida al mercado y añadir valor. Aumentamos la productividad y la calidad, reduciendo los requisitos de cualificación de los desarrolladores.');

-- INSERTAR DATOS sobre_nosotros
INSERT INTO sobre_nosotros (titulo_esp, contenido_esp) VALUES ('Misión', 'Nuestra misión es ofrecer soluciones digitales innovadoras y de alta calidad que impulsen el éxito de nuestros clientes, ayudándolos a alcanzar sus objetivos empresariales a través de la tecnología y la creatividad.');
INSERT INTO sobre_nosotros (titulo_esp, contenido_esp) VALUES ('Visión', 'Nos visualizamos como líderes en el campo de la consultoría y desarrollo de software, reconocidos por nuestra excelencia en el servicio al cliente, nuestra capacidad para adaptarnos a las necesidades cambiantes del mercado y nuestra contribución al crecimiento y la transformación digital de las empresas');

-- GET / ALL servicios
SELECT * FROM servicios;

-- GET / BY ID servicio
SELECT * FROM servicios WHERE id = 1;

-- GET / ALL sobre_nosotros
SELECT * FROM sobre_nosotros;

-- GET / BY ID sobre_nosotros
SELECT * FROM sobre_nosotros WHERE id = 1;